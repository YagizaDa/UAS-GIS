package lapor.uasga.a110121003067005;

public class DataLaporan {

    String pesan;
    Boolean kode_status;

    public String getPesan() {
        return pesan;
    }

    public Boolean getKode_status() {
        return kode_status;
    }
}
